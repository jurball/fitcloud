CREATE SCHEMA IF NOT EXISTS `sportmi`;
USE `sportmi` ;

-- -----------------------------------------------------
-- Table `sportmi`.`orders`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sportda`.`orders` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product` VARCHAR(50) NOT NULL,
  `ind` INT NOT NULL,
  `city` VARCHAR(50) NOT NULL,
  `street` VARCHAR(100) NOT NULL,
  `log` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `sportmi`.`store`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sportmi`.`store` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product` VARCHAR(22) NOT NULL,
  `price` INT NOT NULL,
  `description` VARCHAR(2000) NOT NULL,
  `quantity` INT NOT NULL,
  `img` LONGBLOB NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `product` (`product` ASC) VISIBLE)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `sportmi`.`support`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sportmi`.`support` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(24) NOT NULL,
  `tele` VARCHAR(22) NOT NULL,
  `mail` VARCHAR(70) NOT NULL,
  `message` VARCHAR(5000) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `sportmi`.`users`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sportmi`.`users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(22) NOT NULL,
  `last` VARCHAR(22) NOT NULL,
  `telep` VARCHAR(19) NOT NULL,
  `email` VARCHAR(70) NOT NULL,
  `pass` VARCHAR(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `telep` (`telep` ASC) VISIBLE,
  UNIQUE INDEX `email` (`email` ASC) VISIBLE)
ENGINE = InnoDB;